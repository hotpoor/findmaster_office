settings={
    "QiniuAccessKey": "oAUZmGaVbXLBrfWW5MykZ2_Wr9kmS4FB_1Ij3mpo",
    "QiniuSecretKey": "lOzMXu2LZkfHOvIarlFpQ5WaOYoxqRuXX0aK_aqs",
    "user_id": "e332ed4385cc47ed8d908825eb6b493c",
}